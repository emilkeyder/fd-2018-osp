# OSP Planner: Implementation of Branch-and-Bound search and OSP task reformulation for heuristic computation

## Running the planner:
1. Blind Branch-and-Bound (currently best performing overall configuration)
```
./fast-downward.py domain.pddl problem.pddl --search "best_first_bnb(eval_pruning=osp_blind(),eval_guidance=blind())"
```

2. Merge&Shrink, state-delta reformulation:
```
./fast-downward.py domain.pddl problem.pddl --heuristic "ms=merge_and_shrink(shrink_strategy=shrink_bisimulation(greedy=false),merge_strategy=merge_sccs(order_of_sccs=topological,merge_selector=score_based_filtering(scoring_functions=[goal_relevance,dfp,total_order(atomic_before_product=false,atomic_ts_order=reverse_level,product_ts_order=new_to_old)])),label_reduction=exact(before_shrinking=true,before_merging=false),max_states=50000,threshold_before_merge=1,transform=utility_to_cost(parent=sas_transform(exclude_unused_vars=true, exclude_nonutil_vars=true)))" --search "best_first_bnb(eval_pruning=osp_ms(eval=ms, recompute_costs=false),eval_guidance=blind())"
```

# OSP planner built on top of Fast Downward

The Fast Downward license info is below. 

## Fast Downward and its license
Fast Downward is a domain-independent planning system.

For documentation and contact information see http://www.fast-downward.org/.

The following directories are not part of Fast Downward as covered by this
license:

* ./src/search/ext

For the rest, the following license applies:

```
Fast Downward is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

Fast Downward is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <http://www.gnu.org/licenses/>.
```
